export const storageKeys = {
  ENABLED: "ENABLED",
  TOGGLE_KEY: "TOGGLE_KEY",
} as const;
