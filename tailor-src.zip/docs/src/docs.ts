import Tailor from "../../src/index";

new Tailor();
